/****************************************************************************
**
** StdAfx.cpp -- Source file for generating precompiled header.
**
**     Date                   Modification                          Author
** -----------|----------------------------------------------------|----------
**  2001/01/02 Initial version.                                     C. Monroe
**  2008/01/15 Updates for VS 2005.                                 C. Monroe
**
*****************************************************************************
*/

#include "stdafx.h"

#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#endif
