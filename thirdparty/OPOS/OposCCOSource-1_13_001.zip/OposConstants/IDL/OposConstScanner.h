//*************************************************************************
//** OPOS Scanner Constants
//*************************************************************************

typedef [helpstring("OPOS Scanner Constants")]
enum
{
    SCAN_SDT_UPCA                             = 101,
    SCAN_SDT_UPCE                             = 102,
    SCAN_SDT_JAN8                             = 103,
    SCAN_SDT_EAN8                             = 103,
    SCAN_SDT_JAN13                            = 104,
    SCAN_SDT_EAN13                            = 104,
    SCAN_SDT_TF                               = 105,
    SCAN_SDT_ITF                              = 106,
    SCAN_SDT_Codabar                          = 107,
    SCAN_SDT_Code39                           = 108,
    SCAN_SDT_Code93                           = 109,
    SCAN_SDT_Code128                          = 110,
    SCAN_SDT_UPCA_S                           = 111,
    SCAN_SDT_UPCE_S                           = 112,
    SCAN_SDT_UPCD1                            = 113,
    SCAN_SDT_UPCD2                            = 114,
    SCAN_SDT_UPCD3                            = 115,
    SCAN_SDT_UPCD4                            = 116,
    SCAN_SDT_UPCD5                            = 117,
    SCAN_SDT_EAN8_S                           = 118,
    SCAN_SDT_EAN13_S                          = 119,
    SCAN_SDT_EAN128                           = 120,
    SCAN_SDT_OCRA                             = 121,
    SCAN_SDT_OCRB                             = 122,
    SCAN_SDT_RSS14                            = 131,
    SCAN_SDT_RSS_EXPANDED                     = 132,
    SCAN_SDT_GS1DATABAR                       = 131,
    SCAN_SDT_GS1DATABAR_E                     = 132,
    SCAN_SDT_CCA                              = 151,
    SCAN_SDT_CCB                              = 152,
    SCAN_SDT_CCC                              = 153,
    SCAN_SDT_PDF417                           = 201,
    SCAN_SDT_MAXICODE                         = 202,
    SCAN_SDT_DATAMATRIX                       = 203,
    SCAN_SDT_QRCODE                           = 204,
    SCAN_SDT_UQRCODE                          = 205,
    SCAN_SDT_AZTEC                            = 206,
    SCAN_SDT_UPDF417                          = 207,
    SCAN_SDT_OTHER                            = 501,
    SCAN_SDT_UNKNOWN                          = 0
} OPOSScannerConstants;
