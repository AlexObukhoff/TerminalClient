//*************************************************************************
//** OPOS Totals Constants
//*************************************************************************

typedef [helpstring("OPOS Totals Constants")]
enum
{
    OPOS_ETOT_NOROOM                          = 201,
    OPOS_ETOT_VALIDATION                      = 202
} OPOSTotalsConstants;
