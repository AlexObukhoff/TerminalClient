//*************************************************************************
//** OPOS CashDrawer Constants
//*************************************************************************

typedef [helpstring("OPOS CashDrawer Constants")]
enum
{
    CASH_SUE_DRAWERCLOSED                     = 0,
    CASH_SUE_DRAWEROPEN                       = 1
} OPOSCashDrawerConstants;
