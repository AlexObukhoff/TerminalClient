//*************************************************************************
//** OPOS Scale Constants
//*************************************************************************

typedef [helpstring("OPOS Scale Constants")]
enum
{
    SCAL_WU_GRAM                              = 1,
    SCAL_WU_KILOGRAM                          = 2,
    SCAL_WU_OUNCE                             = 3,
    SCAL_WU_POUND                             = 4,
    SCAL_SN_DISABLED                          = 1,
    SCAL_SN_ENABLED                           = 2,
    SCAL_SUE_STABLE_WEIGHT                    = 11,
    SCAL_SUE_WEIGHT_UNSTABLE                  = 12,
    SCAL_SUE_WEIGHT_ZERO                      = 13,
    SCAL_SUE_WEIGHT_OVERWEIGHT                = 14,
    SCAL_SUE_NOT_READY                        = 15,
    SCAL_SUE_WEIGHT_UNDER_ZERO                = 16,
    OPOS_ESCAL_OVERWEIGHT                     = 201,
    OPOS_ESCAL_UNDER_ZERO                     = 202,
    OPOS_ESCAL_SAME_WEIGHT                    = 203
} OPOSScaleConstants;
