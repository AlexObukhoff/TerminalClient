//*************************************************************************
//** OPOS ElectronicValueRW Constants
//*************************************************************************

typedef [helpstring("OPOS ElectronicValueRW Constants")]
enum
{
    EVRW_CCS_ENTRY                            = 0x00000001,
    EVRW_CCS_DETECT                           = 0x00000002,
    EVRW_CCS_CAPTURE                          = 0x00000004,
    EVRW_CDC_RWCONTROL                        = 0x00000001,
    EVRW_CDC_APPLICATIONCONTROL               = 0x00000002,
    EVRW_DS_NOCARD                            = 1,
    EVRW_DS_DETECTED                          = 2,
    EVRW_DS_ENTERED                           = 3,
    EVRW_DS_CAPTURED                          = 4,
    EVRW_LS_OK                                = 1,
    EVRW_LS_NEARFULL                          = 2,
    EVRW_LS_FULL                              = 3,
    EVRW_AL_REPORTING                         = 1,
    EVRW_AL_SETTLEMENT                        = 2,
    EVRW_BD_ANY                               = 1,
    EVRW_BD_SPECIFIC                          = 2,
    EVRW_TA_TRANSACTION                       = 11,
    EVRW_TA_NORMAL                            = 12,
    EVRW_SUE_LS_OK                            = 11,
    EVRW_SUE_LS_NEARFULL                      = 12,
    EVRW_SUE_LS_FULL                          = 13,
    EVRW_SUE_DS_NOCARD                        = 21,
    EVRW_SUE_DS_DETECTED                      = 22,
    EVRW_SUE_DS_ENTERED                       = 23,
    EVRW_SUE_DS_CAPTURED                      = 24,
    OPOS_EVRW_NOCARD                          = 201,
    OPOS_EVRW_RELEASE                         = 202,
    OPOS_EVRW_CENTERERROR                     = 203,
    OPOS_EVRW_COMMANDERROR                    = 204,
    OPOS_EVRW_RESET                           = 205,
    OPOS_EVRW_COMMUNICATIONERROR              = 206,
    OPOS_EVRW_LOGOVERFLOW                     = 207,
    OPOS_EVRW_DAILYLOGOVERFLOW                = 208,
    OPOS_EVRW_DEFICIENT                       = 209,
    OPOS_EVRW_OVERDEPOSIT                     = 210
} OPOSElectronicValueRWConstants;
