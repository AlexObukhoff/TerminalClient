//*************************************************************************
//** OPOS SigCap Constants
//*************************************************************************

typedef [helpstring("OPOS SigCap Constants")]
enum
{
    zNoConstants_SigCap
} OPOSSigCapConstants;
