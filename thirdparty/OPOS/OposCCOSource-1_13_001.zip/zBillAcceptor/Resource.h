//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BillAcceptor.rc
//
#define IDS_PROJNAME 100
#define IDB_OPOSBILLACCEPTOR  101
#define IDR_OPOSBILLACCEPTOR  102
#define IDB_OPOSBILLACCEPTOR2 201

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE   202
#define _APS_NEXT_COMMAND_VALUE  32768
#define _APS_NEXT_CONTROL_VALUE    201
#define _APS_NEXT_SYMED_VALUE      103
#endif
#endif
