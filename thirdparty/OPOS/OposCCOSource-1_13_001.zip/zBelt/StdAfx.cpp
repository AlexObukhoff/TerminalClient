/****************************************************************************
**
** StdAfx.cpp -- Source file for generating precompiled header.
**
**     Date                   Modification                          Author
** -----------|----------------------------------------------------|----------
**  1999/02/06 Initial version.                                     C. Monroe
**  2008/01/15 Updated for building with VS2005.                    C. Monroe
**
*****************************************************************************
*/

#include "stdafx.h"

#ifdef _ATL_STATIC_REGISTRY
#include <statreg.h>
#endif
