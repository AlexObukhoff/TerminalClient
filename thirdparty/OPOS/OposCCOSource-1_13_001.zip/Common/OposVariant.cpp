/****************************************************************************
**
** OposVariant.cpp -- Helper class for preparing and sending OPOS parameters
**                    as VARIANTS.
**
**      Date                   Modification                          Author
** -----------|----------------------------------------------------|----------
**  1999/02/06 Initial version.                                     C. Monroe
**  1999/03/03 Revamp. No longer rely on CComVariant.
**  1999/03/22 Initialize VARIANTs before use.
**  2004/10/21 Correct ChangeBSTR to clear temporary "vt".
**  2006/08/17 Add VARIANT support.
**  2008/01/15 Clarify usage. Set "hr" on Set or Change failure.
**  2008/08/30 Correct SetDispatch_Ptr so interface pointer is
**               released on destruction.
**
*****************************************************************************
**
{{Begin License}}

Copyright (c) 1999-2008; RCS; A Division of NCR; Dayton, Ohio, USA.
Developed by Curtiss Monroe.

This software is provided "AS IS", without warranty of any kind, express or
implied. In no event shall NCR (including its subsidiaries, employees, and
contributors) be held liable for any direct, indirect, incidental, special,
or consequential damages arising out of the use of or inability to use this
software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:
    1. Redistributions of source code, whether original or altered, must
       retain this license.
    2. Altered versions of this software must be plainly marked as such and
       must not be misrepresented as being the original source or binary.
       Such altered versions also must not be misrepresented as RCS or NCR
       software releases.

{{End License}}
*/

/*
    OposVariant is a wrapper class for the VARIANT structure. It is _not_ a
    general purpose wrapper. Instead, it is optimized for use within the OPOS CCOs.

    OposDispParms is a wrapper class for the DISPPARMS structure.

    See OposVariant.h for usage details.
*/

#include "stdafx.h"
#include "OposVariant.h"


//****************************************************************************
//****************************************************************************


//===========================================================================
// Boolean
//===========================================================================

void OposVariant::SetVARIANT_BOOL(VARIANT_BOOL bSrc)
{
    Clear();
    vt = VT_BOOL;
    boolVal = bSrc ? VARIANT_TRUE : VARIANT_FALSE;
}

//-----------------------------------------------------------------------

void OposVariant::SetVARIANT_BOOL_Ptr( VARIANT_BOOL* pbSrc, HRESULT& hr )
{
    Clear();

    // Validate that the parameter is not NULL.
    if ( pbSrc == 0 )
        hr = E_POINTER;

    // Set the variant.
    else
    {
        vt = VT_BYREF | VT_BOOL;
        pboolVal = pbSrc;
    }
}

//===========================================================================
// Long
//===========================================================================

LONG OposVariant::GetLONG()
{
    LONG nLong = 0;
    HRESULT hr;
    ChangeLONG( &nLong, hr );
    return nLong;
}

//-----------------------------------------------------------------------

void OposVariant::ChangeLONG( LONG* pLong, HRESULT& hr )
{
    // Validate that the parameter is not NULL.
    if ( pLong == 0 )
        hr = E_POINTER;

    // If pointer OK, set it after trying to coerce variant.
    else
    {
        VARIANT var;
        var.vt = VT_EMPTY;
        hr = VariantChangeType(
            &var, static_cast<VARIANT*>(this), 0, VT_I4 );
        *pLong = ( hr == S_OK ) ? var.lVal : 0;
    }
}

//-----------------------------------------------------------------------

void OposVariant::SetLONG(LONG nSrc)
{
    Clear();
    vt = VT_I4;
    lVal = nSrc;
}

//-----------------------------------------------------------------------

void OposVariant::SetLONG_Ptr( LONG* pnSrc, HRESULT& hr )
{
    Clear();

    // Validate that the parameter is not NULL.
    if ( pnSrc == 0 )
        hr = E_POINTER;

    // Set the variant.
    else
    {
        vt = VT_BYREF | VT_I4;
        plVal = pnSrc;
    }
}

//===========================================================================
// Currency
//===========================================================================

void OposVariant::ChangeCURRENCY( CY* pcySrc, HRESULT& hr )
{
    // Validate that the parameter is not NULL.
    if ( pcySrc == 0 )
        hr = E_POINTER;

    // If pointer OK, set it after trying to coerce variant.
    else
    {
        VARIANT var;
        var.vt = VT_EMPTY;
        hr = VariantChangeType(
            &var, static_cast<VARIANT*>(this), 0, VT_CY );
        if ( hr == S_OK )
            *pcySrc = var.cyVal;
        else
            pcySrc->int64 = 0;
    }
}

//-----------------------------------------------------------------------

void OposVariant::SetCURRENCY(CY cySrc)
{
    Clear();
    vt = VT_CY;
    cyVal = cySrc;
}

//-----------------------------------------------------------------------

void OposVariant::SetCURRENCY_Ptr( CY* pcySrc, HRESULT& hr )
{
    Clear();

    // Validate that the parameter is not NULL.
    if ( pcySrc == 0 )
        hr = E_POINTER;

    // Set the variant.
    else
    {
        vt = VT_BYREF | VT_CY;
        pcyVal = pcySrc;
    }
}

//===========================================================================
// BString
//===========================================================================

// Note: The caller must free the current string at pbstrSrc, if needed.
void OposVariant::ChangeBSTR( BSTR* pbstrSrc, HRESULT& hr )
{
    // Validate that the parameter is not NULL.
    if ( pbstrSrc == 0 )
        hr = E_POINTER;

    // If pointer OK, set it after trying to coerce variant.
    else
    {
        VARIANT var;
        var.vt = VT_EMPTY;
        hr = VariantChangeType(
            &var, static_cast<VARIANT*>(this), 0, VT_BSTR );
        *pbstrSrc = ( hr == S_OK ) ? var.bstrVal : 0;
        // Note: We must not call VariantClear on var, or the returned
        //   BSTR will be deleted.
    }
}

//-----------------------------------------------------------------------

void OposVariant::SetBSTR(BSTR bstrSrc, HRESULT& hr )
{
    // If non-NULL BSTR, then just pass BSTR in the variant.
    //   _bNeedClear flag remains off because we are not responsible
    //   for deleting the BSTR.
    if ( bstrSrc != 0 )
    {
        Clear();
        vt = VT_BSTR;
        bstrVal = bstrSrc;
    }

    // If NULL BSTR, call function so that zero-length BSTR is passed.
    //   This may prevent a lazy/bad service objects from causing GPF,
    //   in case they don't check each BSTR for NULL.
    else
        SetBSTR_Copy( 0, hr );
}

//-----------------------------------------------------------------------

void OposVariant::SetBSTR_Copy( BSTR bstrSrc, HRESULT& hr )
{
    Clear();

    // Allocate a BSTR and copy source BSTR into it.
    bstrVal = SysAllocStringLen(
           bstrSrc ? bstrSrc : L"",     // Source string, or empty string if NULL.
           SysStringLen(bstrSrc) );     // Length of string; will return zero if NULL.

    // Set HRESULT if failed.
    if ( NULL == bstrVal )
        hr = E_OUTOFMEMORY;
    // Otherwise set variant type, plus set flag so that the BSTR is deleted by destructor.
    else
    {
        vt = VT_BSTR;
        _bNeedClear = true;
    }
}

//-----------------------------------------------------------------------

bool OposVariant::SetBSTR_OutPtr( BSTR* pbstrSrc, HRESULT& hr )
{
    // Perform the in/out work first.
    bool bRC = SetBSTR_InOutPtr( pbstrSrc, hr );

    // If succeeded, then ensure that the BSTR* points to zero:
    //   This relieves subsequent code from needing to know out vs. in/out,
    //   so that they won't wrongly try to reallocate an out.
    if (bRC)
        *pbstrSrc = 0;

    return bRC;
}

bool OposVariant::SetBSTR_InOutPtr( BSTR* pbstrSrc, HRESULT& hr )
{
    Clear();

    // Validate that the parameter is not NULL.
    if ( pbstrSrc == 0 )
    {
        hr = E_POINTER;
        return false;
    }

    // Set the variant.
    vt = VT_BYREF | VT_BSTR;
    pbstrVal = pbstrSrc;
    return true;
}

//===========================================================================
// VARIANT
//===========================================================================

void OposVariant::SetVARIANT( VARIANT& var, VARTYPE Type, HRESULT& hr )
{
    Clear();

    // If type matches (ignoring the BYREF flag), then copy the variant.
    //   Strips the BYREF if present.
    if ( ( var.vt & ~VT_BYREF ) == Type )
    {
        HRESULT hrTmp = VariantCopyInd( this, &var );
        if ( FAILED(hrTmp) )
            hr = hrTmp;
        _bNeedClear = true;
    }
    // If type doesn't match, then return failure.
    else
        hr = E_INVALIDARG;
}

void OposVariant::SetVARIANT_Ptr( VARIANT*& pvar, VARTYPE Type, HRESULT& hr )
{
    Clear();

    // If type is EMPTY, then allow. Callee may set it.
    if ( pvar->vt == VT_EMPTY )
        ;

    // If type matches (ignoring the BYREF flag), then copy the variant.
    //   Strips the BYREF if present.
    else if ( ( pvar->vt & ~VT_BYREF ) == Type )
    {
        HRESULT hrTmp = VariantCopyInd( this, pvar );
        if ( FAILED(hrTmp) )
            hr = hrTmp;
        _bNeedClear = true;
    }

    // If type doesn't match, then return failure.
    else
        hr = E_INVALIDARG;
}

//===========================================================================
// Wide character string
//===========================================================================

void OposVariant::SetString( LPCOLESTR lpszSrc, HRESULT& hr )
{
    Clear();

    // Allocate a BSTR and copy source string into it.
    bstrVal = SysAllocString(
        lpszSrc ? lpszSrc : L"" );  // Source string, or empty string if NULL.

    // Set HRESULT if failed.
    if ( NULL == bstrVal )
        hr = E_OUTOFMEMORY;
    // Otherwise set variant type, plus set flag so that the BSTR is deleted by destructor.
    else
    {
        vt = VT_BSTR;
        _bNeedClear = true;
    }
}

//===========================================================================
// Dispatch pointer
//===========================================================================

void OposVariant::SetDispatch_Ptr( IDispatch* pSrc, HRESULT& hr )
{
    Clear();

    // Validate that the parameter is not NULL.
    if ( pSrc == 0 )
        hr = E_POINTER;

    // Set the variant, plus set flag so that the pointer is released by destructor.
    else
    {
        vt = VT_DISPATCH;
        pdispVal = pSrc;
        pSrc->AddRef();
        _bNeedClear = true;
    }
}


//****************************************************************************
//****************************************************************************


OposDispParms::OposDispParms( OposVariant* pVars, int nVars )
{
    // Initialize the DISPPARAMS to empty.
    rgvarg = 0;
    rgdispidNamedArgs = 0;
    cArgs = 0;
    cNamedArgs = 0;

    // If some variables and we successfully allocate memory...
    if ( nVars != 0 && ( rgvarg = new VARIANT[nVars] ) != 0 )
    {
        cArgs = nVars;          // Set variable count.
        while ( --nVars >= 0 )  // Copy VARIANTs from OposVariant array.
            rgvarg[nVars] = pVars[nVars];
    }
}

OposDispParms::~OposDispParms()
{
    if (rgvarg)
        delete [] rgvarg;
}

// end OposVariant.cpp
