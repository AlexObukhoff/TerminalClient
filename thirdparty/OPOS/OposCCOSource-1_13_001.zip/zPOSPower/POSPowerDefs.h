/****************************************************************************
**
** POSPowerDefs.h -- Constants and preprocessor macros.
**
**     Date                   Modification                          Author
** -----------|----------------------------------------------------|----------
**  1999/03/20 Initial version.                                     C. Monroe
**  2010/03/01 Version 1.13.001.
**
*****************************************************************************
**
{{Begin License}}

Copyright (c) 1999-2010; RCS; A Division of NCR; Dayton, Ohio, USA.
Developed by Curtiss Monroe.

This software is provided "AS IS", without warranty of any kind, express or
implied. In no event shall NCR (including its subsidiaries, employees, and
contributors) be held liable for any direct, indirect, incidental, special,
or consequential damages arising out of the use of or inability to use this
software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:
    1. Redistributions of source code, whether original or altered, must
       retain this license.
    2. Altered versions of this software -- including, but not limited to,
       ports to new operating systems or environments, bug fix versions, and
       rebuilt versions -- must be plainly marked as such and must not be
       misrepresented as being the original source or binary. Such altered
       versions also must not be misrepresented as RCS or NCR software
       releases -- including, but not limited to, labeling of the altered
       versions with the names "OPOS Common Control Objects" or "OPOS CCOs"
       (or any variation thereof, including, but not limited to, different
       capitalizations).

{{End License}}
*/

#ifndef __POSPOWERDEFS_H__
#define __POSPOWERDEFS_H__

// Define message numbers for our hidden event firing window.
const LONG WMU_DATA_EVENT           = WM_USER + 100;
const LONG WMU_DIRECT_IO_EVENT      = WM_USER + 101;
const LONG WMU_ERROR_EVENT          = WM_USER + 102;
const LONG WMU_OUTPUT_COMPLETE_EVENT= WM_USER + 103;
const LONG WMU_STATUS_UPDATE_EVENT  = WM_USER + 104;

// Define a reasonably large maximum for strings retrieved from the registry.
#define MAX_REGBUFFER_SIZE 256

// Define our debug assertion and verification macros.
#ifndef CMASSERT
#ifdef _DEBUG
#include <assert.h>
#define CMASSERT(x) assert(x)
#define CMVERIFY(x) assert(x)
#else
#define CMASSERT(x)
#define CMVERIFY(x) x
#endif
#endif

#endif //__POSPOWERDEFS_H__

// End POSPowerDefs.h
