/****************************************************************************
**
** MICR.cpp -- Implementation of DLL Exports.
**
**     Date                   Modification                          Author
** -----------|----------------------------------------------------|----------
**  1999/03/20 Initial version.                                     C. Monroe
**  2010/03/01 Version 1.13.001.
**
*****************************************************************************
**
{{Begin License}}

Copyright (c) 1999-2010; RCS; A Division of NCR; Dayton, Ohio, USA.
Developed by Curtiss Monroe.

This software is provided "AS IS", without warranty of any kind, express or
implied. In no event shall NCR (including its subsidiaries, employees, and
contributors) be held liable for any direct, indirect, incidental, special,
or consequential damages arising out of the use of or inability to use this
software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it freely,
subject to the following restrictions:
    1. Redistributions of source code, whether original or altered, must
       retain this license.
    2. Altered versions of this software -- including, but not limited to,
       ports to new operating systems or environments, bug fix versions, and
       rebuilt versions -- must be plainly marked as such and must not be
       misrepresented as being the original source or binary. Such altered
       versions also must not be misrepresented as RCS or NCR software
       releases -- including, but not limited to, labeling of the altered
       versions with the names "OPOS Common Control Objects" or "OPOS CCOs"
       (or any variation thereof, including, but not limited to, different
       capitalizations).

{{End License}}
*/

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>

#include "MICR.h"
#include "MICR_i.c"
#include "MICRImpl.h"


CComModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_OPOSMICR, COPOSMICR)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
        _Module.Init(ObjectMap, hInstance, &LIBID_OposMICR_CCO);
        DisableThreadLibraryCalls(hInstance);
    }
    else if (dwReason == DLL_PROCESS_DETACH)
        _Module.Term();
    return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}

// End MICR.cpp
