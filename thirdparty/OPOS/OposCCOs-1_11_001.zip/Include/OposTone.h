/////////////////////////////////////////////////////////////////////
//
// OposTone.h
//
//   Tone Indicator header file for OPOS Applications.
//
// Modification history
// ------------------------------------------------------------------
// 1997-06-04 OPOS Release 1.2                                   CRM
//
/////////////////////////////////////////////////////////////////////

#if !defined(OPOSTONE_H)
#define      OPOSTONE_H


#include "Opos.h"


// No definitions required for this version.


#endif                  // !defined(OPOSTONE_H)
